<!DOCTYPE html>
<html>

<head>
    <title>Display File Data</title>
    <link rel="icon" href="images/favicon.png" type="image/png">
    <title>Pricing Page</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/92d70a2fd8.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("C:/xampp/htdocs/NiceAdmin/images/pricebg.jpg");
            /* Replace 'images/background.jpg' with your desired image path */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        .navbar {
            position: relative;
            min-height: 128px;
            margin-bottom: 20px;
            border: 1px solid transparent;
        }

        .bg-light {
            background-color: #8AC53F !important;
        }

        .file-data {
            border-collapse: collapse;
            width: 100%;
        }

        .file-data th,
        .file-data td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        .file-data th {
            background-color: blue;
            font-weight: bold;
            color: white;
        }

        #search-form {
            margin-top: 20px;
            margin-bottom: 20px;
        }

        #search-input {
            border-radius: 20px;
            padding: 5px 10px;
            width: 223px;
            border: antiquewhite;
            cursor: pointer;
        }

        #search-btn {
            border-radius: 20px;
            padding: 5px 20px;
            background-color: #ffffff;
            color: #8ac53f;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
        }

        #search-btn:hover {
            background-color: #8ac53f;
            color: #fff;
        }

        .file-data tr:hover {
            background-color: #8ac53f8c;
            color: #000;
        }

        .btn-outline-success {
            border-color: #ffffff;
            color: #28a745;
            border-radius: 17px;
        }

        .file-data th {
            font-weight: bold;
        }
    </style>
    <script>
        $(document).ready(function() {
            // Function to filter table rows based on the search input
            $("#search-btn").on("click", function() {
                var value = $("#search-input").val().toLowerCase();
                $(".file-data tbody tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                });
            });

            // Function to clear the search and show the full table
            $("#search-input").on("input", function() {
                var value = $(this).val().toLowerCase();
                $(".file-data tbody tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1 || value === "");
                });
            });
        });
    </script>
</head>

<body>
    <header class="fixed-header">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <!-- <a class="navbar-brand mx-auto" href="#">
                    <img src="images/logo.png" alt="Logo" style="width: 402px; height: auto;">
                </a> -->
                <span class="navbar-text mr-auto text-white h1">Pricing</span>
            </div>
            <div id="search-form">
                <input type="text" id="search-input" placeholder="Search here....">
                <button class="btn-outline-success" id="search-btn">Search</button>
            </div>
        </nav>
    </header>

    <div class="container">

        <?php
        require 'vendor/autoload.php';

        use PhpOffice\PhpSpreadsheet\IOFactory;

        $filePath = 'C:/xampp/htdocs/NiceAdmin/testing/uploads/';
        $fileName = file_get_contents('C:/xampp/htdocs/NiceAdmin/current_file.txt');
        $filePath .= $fileName;

        if (file_exists($filePath)) {
            $spreadsheet = IOFactory::load($filePath);
            $worksheet = $spreadsheet->getActiveSheet();

            echo "<table class='file-data'>";
            $mergedCells = $worksheet->getMergeCells();
            $processedCells = [];

            foreach ($worksheet->getRowIterator() as $row) {
                echo "<tr>";
                $cellIterator = $row->getCellIterator();
                $cellIterator->setIterateOnlyExistingCells(false);

                $columnIndex = 1;
                foreach ($cellIterator as $cell) {
                    $cellValue = $cell->getValue();
                    $cellStyle = $cell->getStyle();
                    $backgroundColor = $cellStyle->getFill()->getStartColor()->getRGB();
                    $fontStyle = $cellStyle->getFont()->getBold() ? "font-weight: bold;" : "";

                    $tdStyle = "";
                    if ($backgroundColor !== null) {
                        $tdStyle .= "background-color: #" . $backgroundColor . ";";
                    }
                    if ($fontStyle !== "") {
                        $tdStyle .= $fontStyle;
                    }

                    $rowIndex = $cell->getRow();
                    $cellAddress = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($columnIndex) . $rowIndex;

                    if (isset($processedCells[$cellAddress])) {
                        continue;
                    }

                    $mergeRange = $worksheet->getCell($cellAddress)->getMergeRange();
                    if (in_array($mergeRange, $mergedCells)) {
                        $mergeBounds = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::rangeDimension($mergeRange);

                        $colspan = isset($mergeBounds[0]['columns']) ? $mergeBounds[0]['columns'] : 1;
                        $rowspan = isset($mergeBounds[0]['rows']) ? $mergeBounds[0]['rows'] : 1;

                        $tdAttributes = "colspan='$colspan' rowspan='$rowspan'";
                        $processedCells[$cellAddress] = true;
                    } else {
                        $tdAttributes = "";
                    }

                    echo "<td style='$tdStyle' $tdAttributes>$cellValue</td>";
                    $columnIndex++;
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "File not found.";
        }
        ?>











    </div>
</body>

</html>