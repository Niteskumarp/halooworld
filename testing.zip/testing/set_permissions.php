<?php
$directoryPath = 'C:/xampp/htdocs/NiceAdmin/testing/uploads/';

// Set the desired permissions (read and write for owner, group, and others)
$permissions = 0777;

// Set the permissions for the directory
if (!chmod($directoryPath, $permissions)) {
    echo "Failed to set permissions for the directory.";
} else {
    echo "Permissions set successfully for the directory.";
}
?>
