<?php
// Get the uploaded file details
$file = $_FILES['file']['tmp_name'];
$fileName = $_FILES['file']['name'];

// Move the uploaded file to a desired location
move_uploaded_file($file, 'C:/xampp/htdocs/NiceAdmin/testing/uploads//' . $fileName);

// Store the file name in a text file
file_put_contents('C:\xampp\htdocs\NiceAdmin\current_file.txt', $fileName);

// Redirect to the second HTML page
header("Location: display_file_data.php");
exit;
?>
